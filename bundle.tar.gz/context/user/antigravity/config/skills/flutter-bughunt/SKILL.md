---
name: flutter-bughunt
description: Adversarial Flutter/Android correctness bug hunt for Boorusphere. Use when asked to hunt real bugs that survive ordinary review — races, lifecycle and use-after-dispose, async ordering, state-machine holes, error-recovery gaps, platform-channel and device edge cases — in a chosen subsystem, file, or folder. Not for flutter analyze cleanup, lint fixes, or UI polish.
argument-hint: "[subsystem | file | folder]"
---

# Adversarial Flutter/Dart Bug Hunt — Boorusphere

## Scope

Treat the invocation argument (e.g. `/flutter-bughunt lib/features/search`) as the scope for this run. If it is empty or whitespace, pick ONE highest-risk subsystem yourself — booru engine/parsers, page+pagination pipeline, downloader, storage/backup, or boot sequence — and state which one and why. If it names a directory, narrow to the highest-risk file inside it and say which. Do not sweep the whole `lib/`; a shallow pass over everything is a failed run.

This is NOT a conventional Dart code review, NOT a `flutter analyze` cleanup, and NOT a UI polish pass.

Objective: discover real application correctness bugs — subtle, intermittent, device-dependent, timing-dependent, lifecycle-dependent, state-dependent, network-dependent, and security-relevant bugs that another competent Flutter developer would reasonably miss. Assume undiscovered bugs exist. Do not optimize for the number of findings; optimize for findings that survive superficial review.

## Operating rules

1. Valid Dart or analyzer-clean does not mean correct application behavior.
2. Do not stop at missing null checks, unawaited futures, unchecked async gaps, unhandled exceptions, or lint violations. That is the lowest layer.
3. Trace behavior across widget, provider, repository, parser, platform-channel, isolate, and native boundaries. A bug may require several files to demonstrate.
4. Never infer correctness from one function, widget, or provider in isolation.
5. Treat this codebase, upstream packages, Flutter framework code, and generated code as not automatically correct.
6. Analyzer cleanliness, a green test suite, a clean DevTools timeline, and "it works on my phone" are not proof.
7. Do not call something a race because two `await`s look interleavable. Demonstrate a reachable schedule and the violated invariant.
8. Do not present speculation as a confirmed bug.
9. Do not modify code merely because a suspicious pattern exists. During discovery, investigate before fixing; do not fix the first bug you encounter.
10. Before declaring the subsystem correct, actively attempt to falsify its invariants.
11. Keep the report dense: every sentence carries evidence. No filler, no restating this prompt, no per-finding padding.
12. The phases are an internal checklist, not an output format. Do not emit per-phase narration or fourteen shallow summaries. The only deliverable is the Phase 13 report; a run that replaces a few deep proofs with many shallow phase summaries has failed.

## Phase 0: System reconstruction

Reconstruct only the scoped subsystem. When a checklist item lies outside scope, note the dependency and move on. Budget: roughly 30 lines of compact tables or lists, no prose.

Inventory (lookup checklist):

- models and entities: `Post`, `PageData`, `PageOption`, `Server`, `Suggestion`, `FetchResult`, `DownloadEntry`, `DownloadProgress`, `BooruError` (Freezed / Hive / DTO)
- provider graph: which provider `watch`es which, which are `keepAlive`, which auto-dispose, which are `family`-parameterized, which are overridden at boot
- state machines: `FetchResult` (`idle/loading/data/error`), download entry, server scan/manual add, app boot, restore/import, player
- shared mutable state: notifier `state` fields, `PageState._page`/`_fetching`, Hive boxes, cookie jar, sqflite handle (downloads), static singletons
- async primitives: `Completer`, `StreamController` (single/broadcast), `StreamSubscription`, `Isolate`/`ReceivePort`, `Future.microtask`, `Timer`/`Timer.periodic`, debounce/throttle, `unawaited`
- platform channels: pigeon interfaces (`pigeons/*.pi.dart`), `EnvRepo`, downloader callbacks, notifications, permission_handler, media_scanner, wakelock, flutter_displaymode
- native side: Kotlin/Java under `android/`, its threading model, plugin service lifecycle
- network: Dio + interceptors, `dio_smart_retry`, cookie jar, redirects, timeouts, TLS/proxy
- persistence: Hive box open/close ordering, adapters, migrations, backup/restore format, file I/O, `flutter_cache_manager`, sqflite
- navigation: auto_route config, guards, deep links/share intents
- media pipeline: `cached_network_image`, image decode, `video_player` surface, audio focus, wakelock
- boot path: `lib/main.dart` → repo `prepare()` → `ProviderScope` overrides → `initializeAsyncStates` → `MaterialApp.router`

Lifecycle chain per object: creation/allocation → initialization (provider first read, `initState`, build) → publication (provider emit, `setState`, Hive write, route push) → normal use → asynchronous use (after `await`, after dispose, after pop) → teardown (`ref.onDispose`, `State.dispose`, `close()`) → unpublication (invalidate, pop, unmount) → final reference release → resource cleanup. Identify every function involved in those transitions.

Execution contexts that can touch each object: main-isolate frame; microtask queue; event queue (timers, I/O callbacks); continuation after `await`; stream listener; animation ticker; `WidgetsBindingObserver`/`AppLifecycleState`; `NavigatorObserver`; background isolate (`Isolate.spawn`, `compute`); pigeon/MethodChannel handler (Android main vs plugin worker); flutter_downloader background callback; native Android main/background thread; plugin native service (downloader, video, image decoder, notification).

Every `await` is a preemption point. Identify code that assumes it will not be preempted across one. For each piece of state, establish which mechanism protects it — provider encapsulation, stream serialization, completer exclusion, an explicit `bool` guard, or nothing — and whether the guard actually covers it. Do not assume a guard protects something merely because it is adjacent; establish the real ordering relationship.

## Phase 1: Invariant discovery

State each invariant explicitly. Seed candidates for this codebase — verify, do not assume:

- a parser must only claim `canParsePage`/`canParseSuggestion` for payloads it can faithfully map; dispatcher fallback in `BooruRepo` must not let a wrong parser "succeed" with empty or wrong posts
- `PageState` page index must stay monotonic and consistent with `PageOption` across skip-blocked-pages, retry, and query changes; no duplicate or skipped posts across pages
- the `_fetching` guard must be released on every exit path (success, error, early return, exception), or the page becomes permanently stuck
- `Server` URL template expansion must percent-encode user tags exactly once and stay valid for both query-string and path templates
- credentials (`user_id`/`api_key`, cookies, session tokens) must never reach logs, error surfaces, exported backups, notifications, or the clipboard
- a provider must not be written to (`state = ...`) after its element is disposed; `ref` must not be used across an async gap that outlives the element
- any `BuildContext` used after an `await` must still be mounted
- a `StreamSubscription`/`Timer`/controller created by a widget or provider must be cancelled before its owner dies
- a `StreamController` must never receive events after `close`; a `Completer` must never complete twice or stay pending forever
- an async result must never be applied to state it no longer matches (stale response, changed query, changed server, disposed scope)
- Hive in-memory and on-disk state must not diverge silently after a failed or partial write; a box must be open before any read/write
- a download entry must reflect actual filesystem state; no orphan file, no orphan progress row
- a cache key must uniquely identify the resource and the file must not be deleted while in use
- the boot sequence must not read a provider before its `ProviderScope` override exists
- `FetchResult` must never remain `loading` after a terminal outcome, and never expose `error` with stale `data` the UI misreads
- a Freezed `copyWith` path must preserve every invariant the constructor enforces
- theme values must flow through `ColorScheme`/`DesignTokens` (DESIGN.md); a hard-coded color is a design invariant violation, not a bug

For each invariant record: state protected, who can modify it, who can observe it, the mechanism meant to protect it, lifetime requirement, execution contexts, platform assumptions (Android API level, permissions, storage model). Build an internal invariant map; later phases must actively falsify it.

## Phase 2: Lifecycle and ownership audit

Do not merely hunt for obvious `dispose` omissions. For every important reference, subscription, or resource determine:

- Who owns it? Who may reference it? What establishes the reference (`ref.watch`, `ref.read`, `StreamSubscription`, closure capture, static field)?
- What ends the reference? What prevents destruction while it is still referenced?
- Can an async callback fire after the provider/widget is disposed?
- Can a stream emit after its controller is closed?
- Can a platform-channel reply arrive after the widget is unmounted?
- Can a timer fire after its owner is gone?
- Can a Hive box or sqflite handle be used after close?
- Can a navigation callback reference a popped route's state?
- Can a background isolate send after the main isolate's port is closed?
- Can a downloader callback reference disposed state, a deleted entry, or a different server context?
- Can an object be published before initialization completes?
- Can an object become unreachable while an async consumer still holds it?

Investigate explicitly: use-after-dispose, double dispose, leaked subscriptions/timers/controllers, leaked native resources (download task, media player, wakelock, notification, file handle), stale closures capturing old state, listeners outliving their source, provider scope mismatch, `ref.read` inside an async gap on an invalidated element, orphaned futures that throw into the void, premature disposal while an operation is in flight, logical-vs-widget lifetime mismatch, orphan files and orphan progress rows. For suspicious cases, construct the exact sequence proving the invalid access.

## Phase 3: Concurrency and async ordering audit

Dart is single-threaded per isolate, but async gaps, microtask ordering, stream interleaving, isolate messaging, and platform callbacks create real hazards; native plugin code runs actual threads.

For every shared mutable state: who writes it, who reads it, at which `await` boundaries, and whether that coordination is sufficient. Specifically:

- can an interleaving observe a half-applied transition?
- can a check-then-act be split by an `await`?
- can two UI actions both pass the same guard?
- can a stale continuation overwrite newer state?
- can `ref.read` between two awaits return a different value, or find the element gone?
- can a provider be invalidated between check and use?
- can stream events arrive out of order, or be dropped by pause/resume/cancel ordering?
- can an isolate message arrive between two related operations?
- can a plugin callback or lifecycle event arrive between "decide" and "act"?
- can two navigations corrupt state, or debounced operations overlap / fire out of order?
- can a `Completer` be completed twice or never?

Search specifically for these shapes:

```
check state -> await -> state changed -> act on stale state
start A -> start B -> B completes first -> A completes and overwrites B
read provider -> await network -> provider invalidated -> use stale data
acquire resource -> await -> resource disposed -> use disposed resource
set flag -> await -> another path clears flag -> invariant broken
submit search -> submit different search -> first response arrives -> wrong results
start download -> user removes entry -> completion writes orphan record
initiate navigation -> async guard evaluates -> second navigation -> race
subscribe -> dispose -> event arrives -> setState on defunct State
parse response -> format differs -> parser returns partial/wrong data
```

These are examples, not exhaustive; derive more from the Phase 1 invariants. A bug that fits none is still a bug.

For every suspected race, write an explicit event-loop schedule:

```
Event Queue:
event A (user tap)
  microtask from A
event B (stream event)
  microtask from B
timer C fires
platform-channel reply D arrives
```

Then state: required preconditions, exact interleaving, violated invariant, observable consequence, and why existing coordination does not prevent it. Do not call something a race without doing this.

Also audit: Future ordering assumptions, subscription listen/pause/resume/cancel ordering, pigeon threading assumptions, provider dependency ordering (circular, diamond), invalidation cascades, `ref.watch` vs `ref.read` correctness, async gaps in `build`, cleanup that `dispose` cannot await, unawaited futures swallowing errors, Zone error handling, multiple Navigator stacks, Hive open/close ordering (single isolate here — the risk is ordering and write-then-crash, not multi-isolate corruption).

## Phase 4: Error, failure, and recovery audit

Treat every failure as a state transition. Enumerate partial-failure shapes:

```
A ok -> B ok -> C fails -> rollback
A ok -> B fails
A ok -> B ok -> C fails -> cleanup fails
retry after partial success
```

For every function doing network I/O, file I/O, persistence, platform calls, permission requests, or async work: enumerate each intermediate failure and ask what state the app is left in.

Fault matrix: timeout, no connectivity, captive portal, HTTP 429/5xx, HTML error page instead of JSON/XML, truncated body, empty body, malformed XML/JSON, unexpected null or type mismatch, credential rejection (servers requiring `user_id`/`api_key`), redirect to an unexpected host, disk full, storage permission denied / permanently denied / revoked mid-download, corrupt Hive box, Hive migration failure, sqflite failure in the download repo, process death mid-write, restore from corrupt or partial backup, server deleted while its page loads, platform channel timeout or exception, large-image decode under memory pressure.

Look for: flags not cleared on error paths, `FetchResult` stuck `loading`, partially written Hive records, partially written files after a cancelled download, rollback that does not restore invariants, non-idempotent retry, UI state diverging from persisted state, error paths with different ordering than success paths, swallowed exceptions, catch-all handlers masking bugs, wrong exception type caught (`DioException` vs `BooruError` vs plugin errors crossing the boundary), JSON parsing that silently defaults missing fields, unrecoverable states requiring restart, snackbar/toast hiding critical failure, retry amplification, cache or backup corruption persisting across launches.

## Phase 5: State-machine audit

Model state machines explicitly and name the transitions:

```
idle -> loading -> data
data -> loading (refresh/pagination) -> data
loading -> error -> loading (retry)
data -> error (page advance fails)
DOWNLOADING -> PAUSED -> DOWNLOADING
DOWNLOADING -> FAILED -> RETRYING
DOWNLOADING -> COMPLETED | CANCELLED | REMOVED
UNINITIALIZED -> SCANNING -> CONFIGURED
FOREGROUND -> BACKGROUND -> FOREGROUND
FOREGROUND -> DETACHED (process death) -> RESTORED
```

For every transition determine: who initiates it (user, system, async completion, lifecycle), what manages it, what async work can be in flight, what dependent widgets/providers can observe mid-transition, whether it is atomic from the UI's perspective, whether rollback exists, whether another transition can race it, and whether process death can interrupt it.

Pay particular attention to multiple booleans or fields representing one conceptual state (e.g. `_fetching` + `state` + `_page` + `option.query`), providers that must transition atomically but are updated independently, navigation state vs data state, download state vs filesystem state, and persisted state vs in-memory state. Determine whether impossible combinations are reachable, and construct them deliberately.

## Phase 6: Platform- and device-facing audit

Do not assume ideal platform behavior. The OS, plugins, and remote servers are adversarial. This phase covers runtime behavior that violates Dart-side assumptions; build/config variants belong to Phase 7.

**6a. Platform channel contracts.** pigeon type fidelity across the Dart/Kotlin boundary; MethodChannel serialization edge cases; channel threading (Android main vs plugin worker); error replies crossing the boundary as a type the Dart catch does not match; plugin service lifecycle vs app process death.

**6b. Android lifecycle vs Flutter lifecycle.** ordering of onPause/onResume/onDestroy against `AppLifecycleState`; activity recreation; process death and restore; configuration changes (rotation, locale, dark mode); native cleanup on Activity destroy; memory-trim callbacks.

**6c. Permissions and storage.** grant / deny / "don't ask again" / revoked later; scoped storage, SAF URIs, MediaStore, file-provider paths; path validity across reboot and SD-card removal; notification permission and channels.

**6d. Background execution and downloads.** Doze and background limits; flutter_downloader native callback isolation; download service lifetime when the app process dies; wakelock acquire/release lifecycle.

**6e. Media pipeline and memory.** image decode of hostile or huge files (decompression bombs, odd EXIF, extreme dimensions); cache eviction while an image is displayed; video player surface lifetime and audio focus; low-memory behavior under large grids.

**6f. Hostile input from servers, intents, and network.** share and deep-link intents as untrusted input; redirects to unexpected hosts; cookie scope leaking across servers; connectivity change mid-request; captive portal.

Distinguish Dart-side ordering assumptions, actual platform execution order, cross-boundary visibility and timing, and resource ownership across the Dart/native boundary. A Dart sequence that looks correct may still violate a platform lifecycle requirement.

## Phase 7: Configuration and environment audit

Determine whether correctness changes under: debug vs profile vs release (asserts stripped, R8/ProGuard, tree-shaking, obfuscation); Android API level (minSdk through latest); device ABI and form factor (phone, tablet, foldable, split screen, PiP); screen density, orientation, font scale, accessibility settings; locale and RTL; dark/light and dynamic color; Impeller vs Skia; low memory; battery saver and Doze; slow network, airplane mode, transitions, proxy/VPN; first launch vs upgrade vs restore-from-backup; cold start vs warm start vs process-death restore; storage/notification permission states; server configuration variants; dataset size (thousands of posts, hundreds of tags); rapid interaction (fast scroll, rapid tap, rapid navigation); deep navigation stacks; system clock changes; non-English payloads.

Do not dismiss a bug because your current device or config does not trigger it. Determine whether the path is reachable under another supported configuration.

## Phase 8: Cross-package, upstream, and sibling differential

Evidence sources: sibling parsers for the same site family; callers and callees; `DESIGN.md`/`PRODUCT.md` intent; `CHANGELOG.md`; `git log`/`git blame`; package changelogs and migration notes (Riverpod, Dio, Hive CE, flutter_downloader, video_player, cached_network_image, permission_handler, slang, auto_route); plugin issue trackers; generated-code contracts (build_runner, Freezed, Riverpod generator, auto_route generator, Hive adapters) vs hand-written assumptions; deprecated APIs; the servers' own API docs and quirks.

Do not audit generated code (`.g.dart`, `.freezed.dart`, `.gr.dart`, `lib/pigeon/*.pi.dart`, `lib/presentation/i18n/strings.g.dart`) for bugs. Audit the inputs to generation — annotations, source classes, `build.yaml`, `slang.yaml`, `pigeons/*.pi.dart` — and the assumptions hand-written code makes about the generated output.

For every relevant upstream change determine: what invariant or failure motivated it, whether the same invariant exists here, whether the same failure can occur here, whether this tree uses it differently, and whether the change is actually correct for this codebase. Use history and changelogs as evidence of intent, not proof of correctness.

## Phase 9: Adversarial execution

Reopen every candidate from Phase 3 and every invariant from Phase 1. Prove it, refute it with a concrete reason, or extend the schedule. Then construct counterexamples for invariants Phase 3 never touched:

```
user: taps load more          | timer: auto-refresh fires     -> duplicate entries
user: navigates to detail     | system: process death         -> restored state inconsistent
user: starts download         | user: switches server         -> callback uses wrong context
user: submits search          | slow response                 -> results for the wrong query
user: changes server in settings -> provider cascade          -> build reads stale ref
user: rapid scroll            | memory pressure, cache evicts -> OOM or blank images
user: grants permission       | onPause before callback       -> permission state inconsistent
UI: tap next -> _fetching = true -> await fetch | UI: tap prev -> guard hit or interleaved?
UI: pop route -> autoDispose fires -> continuation writes state
isolate: sends parsed data    | main: widget disposed         -> update on defunct State
channel: returns error        | dart: catch type mismatch     -> unhandled exception
```

Never merely say "this could race". Establish: exact event sequence, required preconditions, async gaps and queue state, violated invariant, observable consequence, and whether the sequence is actually reachable.

## Phase 10: Rare and high-impact bugs

Do not downgrade a bug because reproduction requires narrow timing, specific network latency, memory pressure, process death at a specific point, rapid interaction, a specific navigation sequence, a specific server response, a specific Android version or permission state, first-launch-only or migration-only conditions, large datasets, a specific locale or text direction, accessibility settings, or a background/foreground transition at the wrong moment. Rare does not mean unimportant. Prioritize by impact — data loss, credential exposure, permanent stuck UI, silent wrong results, crash — not by reproducibility convenience.

## Phase 11: Validation

Use only tooling that exists in this project: `flutter analyze`, `dart fix`, `flutter test` with the existing ~60 test files, mocktail, and riverpod `ProviderContainer` (the only deterministic way to prove provider-lifecycle races). Golden tests and `integration_test` are not set up — do not hunt for missing infrastructure and do not scaffold it unless asked. Also available: `dart format --set-exit-if-changed`; DevTools memory/network/widget inspector and performance overlay; LeakTracking; Android StrictMode and LeakCanary natively; Hive inspector; a local mock server serving hostile payloads (truncated, malformed, HTML, 429, empty, huge); network throttling and airplane-mode toggling; rapid navigation and rapid-tap loops; permission revoke/regrant loops; process-kill/restore loops; low-memory emulator; API-level and ABI matrix checks; TalkBack, large font, high contrast.

Tools are evidence, not proof. A clean run does not invalidate a demonstrated bug unless the test actually exercises the relevant execution. If the app cannot run in the relevant configuration, continue static investigation and clearly separate verified facts from hypotheses.

## Phase 12: Finding classification

Every candidate must be exactly one of: `CONFIRMED BUG`, `HIGHLY PROBABLE BUG`, `PLAUSIBLE / UNPROVEN`, `SUSPICIOUS CODE`, `FALSE POSITIVE`.

A finding cannot be CONFIRMED merely because a suspicious pattern exists. If every finding lands in `SUSPICIOUS CODE` or `PLAUSIBLE / UNPROVEN`, the investigation is incomplete — return to Phase 9 and construct concrete counterexamples. Do not manufacture confidence to hit a quota: a short list of proven bugs beats a long list of suspicions, and relabelling a suspicion as CONFIRMED is exactly the failure this skill exists to prevent.

## Phase 13: Final finding report

Start with a summary table:

```
ID | Location | Class | Severity | Trigger | Confidence | Status
```

Bug class: state / lifecycle / async / platform / data / UI / security / performance. Severity: critical / high / medium / low, based on user-visible impact (data loss, credential exposure, permanent stuck state, silent wrong data, crash, jank).

Per finding, include all of:

1. ID
2. Precise location (`file:line`, widget/provider/function)
3. Bug class
4. Severity
5. Trigger conditions (device, network, lifecycle, config)
6. Relevant execution path
7. Exact violated invariant
8. Concrete interleaving / state transition
9. Observable consequence
10. Why existing guards do not prevent it
11. Configuration/environment dependencies
12. Reproducer or validation strategy
13. Confidence classification
14. Smallest plausible correct fix
15. Potential side effects of that fix (Riverpod rebuild scope, extra rebuilds, API change, persistence compatibility, i18n, DESIGN.md compliance)

Do not inflate severity or confidence. Do not collapse independent bugs because they share a file; conversely, group findings that share one root cause — one defect that disappears when fixed at a single point, not merely the same bug class in two places. Two stale closures in two different callbacks are two findings.

## Phase 14: Remediation accounting

Do not modify the first suspicious code you encounter; finish the investigation first. Then, if modification is requested, give every finding an explicit disposition:

```
FIXED
ALREADY MITIGATED
FALSE POSITIVE
CONSOLIDATED INTO ANOTHER FIX
DEFERRED / INSUFFICIENT EVIDENCE
NOT SAFE TO FIX AUTOMATICALLY
```

Never silently omit a finding. Multiple findings may legitimately be fixed by one change when they share a root cause. For every FIXED finding: identify the exact change, the invariant restored, why it is sufficient, and re-audit provider dependency ordering, widget lifecycle, async-gap safety, platform-channel correctness, error propagation, state consistency, navigation, persistence and backward compatibility (Hive migration, backup format), i18n, DESIGN.md compliance (`ColorScheme`/`DesignTokens`), and performance. Do not modify code merely to increase the number of fixes.

When modification is requested, regenerate code after touching providers/entities/routes/i18n, run `dart format` + `flutter analyze`, and commit per aspect with Conventional Commits. During a discovery-only run, produce findings and stop.

## Final requirement

Do not conclude "no bugs found" merely because it analyzes, tests pass, and the app runs. Before concluding, ask: "How could this invariant be false?" and attempt to construct the counterexample. A clean Dart analysis is NOT a successful result.

A successful result is one of:

1. Concrete evidence of a real bug.
2. A defensible explanation of why a suspected bug is prevented.
3. A defensible explanation of why the subsystem's important invariants survive adversarial execution — naming which invariants you tried to falsify and the exact schedule you tried against each.

The goal is not a long review. The goal is to find bugs that survive ordinary Flutter/Dart code review.
