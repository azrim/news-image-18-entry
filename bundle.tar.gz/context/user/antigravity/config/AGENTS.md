# Global Agent Guidelines

## High-Performance Computing, Solving & Mining Rules

**MANDATORY RULE FOR COMPUTATION, SOLVING, OR MINING:**
Whenever performing Proof-of-Work (PoW) solving, mining, brute-forcing, heavy hashing (e.g. Keccak-256 / SHA3), or any compute-intensive workload:

1. **Switch Power Profile to Max Performance First**:
   Before running any solver, miner, or heavy computation script, switch the Windows power scheme to **Max Performance**:
   ```powershell
   powercfg /setactive f9999999-e8bf-4a96-9a85-a6e23a8c635c
   ```
   Verify active scheme:
   ```powershell
   powercfg /getactivescheme
   ```

2. **Mandatory Native C Implementation**:
   - The core solving, mining, or computational hot path **MUST be implemented in native C** (e.g. `*.c` compiled to `*.exe`).
   - Use GCC with aggressive optimization flags:
     ```powershell
     gcc -O3 -march=native -funroll-loops -o <output>.exe <source>.c
     ```
   - **Prohibited**: Never run compute-heavy solving or mining loops directly in interpreted/scripting languages (pure Python, Node.js, JS). Scripts (Python/JS) may only act as thin I/O coordinators or wrappers that invoke the compiled native C binary (`.exe`).

3. **Post-Computation Cleanup**:
   - When computation finishes and the system returns to idle server mode, restore the power scheme to `Eco 24-7 Server`:
     ```powershell
     powercfg /setactive e00e80ff-c2db-4e28-8136-c4dfd86f227a
     ```

---

## Minting & Contract Call Confirmation Policy

1. **Free Mint (`--value 0` / gratis)**:
   - **TIDAK PERLU konfirmasi user, LANGSUNG EKSEKUSI!**
   - Segera setelah parameter target (kontrak, fungsi calldata, waktu pembukaan) teridentifikasi atau diinstruksikan, langsung jalankan atau siapkan eksekutor (`fire.js`) tanpa menunggu atau menanyakan konfirmasi ulang kepada user.

2. **Paid Mint (`value > 0` / berbayar)**:
   - **WAJIB tanyakan dan minta persetujuan user terlebih dahulu**.
   - Tampilkan rincian biaya (harga dan total BNB/token), tunggu persetujuan eksplisit dari user, serta tetapkan `--value <amount>` dan cap pengaman `--maxValue <amount>` sebelum eksekusi dilakukan.
